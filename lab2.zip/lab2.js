(function() {
	var app = angular.module('schedule',[]);

    var scheduleComponentNames = ["Due", "Topics", "Resources", "Reading", "Programs"];

    var scheduleComponent = {
        name: "Due",
    values: [''] // list of things to display for this component
    };



    var courseComponent = {
        type: 'Lab',
        name: 'Schedule Object',
        number: 1,
        sessionDue: 3,
        url: '../Assignments/SchedulerLab.pdf',
        solution: '',
        sample: ''
    };


    var sS = [{
                week: 1, // value comes from a session object
                session: 2, // value comes from a session object
                sessionDate: 'Wednesday Dec 2', // value comes from a session object
                scheduleComponents: [
                {
                    name: "Topics",
                    values: [
                    "Review of course syllabus",
                    "Brief introduction to Express.js",
                    "MongoDB installation",
                    "Getting started with MongoDB"
                    ]
                },
                {
                    name: "Resources",
                    values: [
                    '<a href="../Slides/Introductions.pdf">Slides</a>',
                    '<a href="http://expressjs.com/starter/installing.html">Express Installation</a>',
                    '<a href="https://docs.mongodb.org/manual/installation/">MongoDB installation</a>'
                    ]
                },
                {
                    name: "Reading",
                    values: [
                    '<a href="../syllabus.html">Course Syllabus</a>',
                    '<a href="https://docs.mongodb.org/manual/">MongoDB Documentation</a>',
                    ' <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript">JavaScript Primer</a>',
                    '<a href="../Assignments/HelloWorldExpressExample.pdf">Hello World Express Exampla</a>',
                    '<a href="../Assignments/GettingStartedWithMongoDB.pdf">Getting Started with MongoDB</a>'
                    ]
                }
                ]
            }];


//////////////////////////////////////////////////////////////////////

            app.controller("ScheduleController",function(){
              this.scheduleSession = sS;
              this.courseName = "Introduction to Teapot Analysis";
              this.courseDesignation = "CSSE-418"
              this.term = 2;
              this.termNames = ["Fall","Winter","Spring", "Summer"];
              this.fiscalYear = 2016;
              this.updated = new Date();
              this.overview = "[additional information about the course might go here]";
              this.componentNames = scheduleComponentNames;
          });

        })();